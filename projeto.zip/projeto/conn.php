<?php
// Arquivo responsável por conectar a nossa base de dados
$hostname_conn = "localhost";
$database_conn = "meusite";
$username_conn = "root";
$password_conn = "";

// Conectamos ao nosso servidor MySQL
if(!($conn = mysqli_connect($hostname_conn,$username_conn,$password_conn))) 
{
   echo "Erro ao conectar ao MySQL.";
   exit;
}
// Selecionamos nossa base de dados MySQL
if(!($con = mysqli_select_db($database_conn,$conn))) 
{
   echo "Erro ao selecionar ao MySQL.";
   exit;
}
?>