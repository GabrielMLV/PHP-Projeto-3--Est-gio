<?php 
	
	
	$email = $_POST["email"];
	$assunto = $_POST["assunto"];
	$texto = $_POST["mensagem"];
	
	
	$mensagem .= "E-mail: $email \n";
	$mensagem .= "Telefone: $assunto \n\n";
	$mensagem .= "Mensagem: $texto \n";

	$destinatario = "biel_matheus20@hotmail.com";
	$remetente = "biel_matheus20@hotmail.com";
	$enviado = "$email";
	$assunto = "Contato Pelo Site";

	$headers = implode ("\n", array("From: $remetente", "Reply-To: $enviado", "Return-Path: $remetente","MIME-Version: 1.0","X-Priority: 3","Content-Type: text/html; charset=UTF-8"));

	echo '<link href="css/bootstrap.css" rel="stylesheet">';
	
	if (mail($destinatario, $assunto, nl2br($mensagem), $headers)) {
		echo "<h3 style='color: white; background: green; margin-top: 0;'>E-mail enviado com sucesso!!!</h3>";
	} else {
		echo "<h3 style='color: white; background: red; margin-top: 0;'>Falha. E-mail não enviado!</h3>";
	}

 ?>