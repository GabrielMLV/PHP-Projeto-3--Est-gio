<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="index.php"><img src="img/logo3.png" width="130" height="50"></a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="index.php" style="color: white" class="home">Home</a>
                </li>

                <li>
                    <a href="computadores.php" style="color: white" class="computadores">Computadores</a>
                </li>

                <li>
                    <a href="faleconosco.php" style="color: white" class="faleconosco">Fale Conosco</a>
                </li>

                <li>
                    <a href="admin/admin-entrar.php" style="color: white" class="admin"><i class="fa fa-user"></i> Admin</a>
                </li>

                <li>
                    <a href="carrinho.php" style="color: white; margin-left: 50px;"><i class="fa fa-shopping-bag"></i> Carrinho</a>
                </li>
            </ul>
        </div>
    </div>
</nav>