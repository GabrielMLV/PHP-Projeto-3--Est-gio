<?php 
include "config.inc.php";
session_start(); 
if(!isset($_SESSION['carrinho'])){
    $_SESSION['carrinho'] = array(); 
} 
//adiciona produto 
if(isset($_GET['acao'])){ 
    //ADICIONAR CARRINHO 
    if($_GET['acao'] == 'add'){ 
        $id = intval($_GET['id']); 
        if(!isset($_SESSION['carrinho'][$id])){ 
            $_SESSION['carrinho'][$id] = 1; 
        }else{ $_SESSION['carrinho'][$id] += 1; } }
    //REMOVER CARRINHO 
    if($_GET['acao'] == 'del'){ 
        $id = intval($_GET['id']); 
        if(isset($_SESSION['carrinho'][$id])){ 
            unset($_SESSION['carrinho'][$id]); } } 
    //ALTERAR QUANTIDADE 
    if($_GET['acao'] == 'up'){ 
        if(is_array($_POST['prod'])){ 
            foreach($_POST['prod'] as $id => $quantidade){

                      $id  = intval($id);
                      $quantidade = intval($quantidade);
                      if(!empty($quantidade) || $quantidade <> 0){
                         $_SESSION['carrinho'][$id] = $quantidade;
                      }else{
                         unset($_SESSION['carrinho'][$id]);
                      }
                   
                     }
                   }
                }
             }
             
           
          
           
           
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Carrinho</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="css/estilo.css">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/shop-homepage.css" rel="stylesheet">

    <link rel="stylesheet" href="css/font-awesome.css">

    <link rel="stylesheet" href="css/locastyle.css">

    <link href="https://fonts.googleapis.com/css?family=Abel|Roboto:400,500,700,900" rel="stylesheet">
    </head>
 
    <body>
     <?php
          include "menu.php";
        ?>
<div class="container">        
<table class="table table-hoverlabel ">
         
<caption ><center><h1>Carrinho de Compras</h1></center></caption>
 
 
<thead>
 
<tr style="color: white;" class="label-primary">
                 
<th width="244">Produtos</th>
 
 
<th width="79">Quantidade</th>
 
 
<th width="89">Pre&ccedil;o</th>
 
 
<th width="100">SubTotal</th>
 
 
<th width="64">Remover</th>
 
              </tr>
 
        </thead>
 
 
<form action="?acao=up" method="post">
 
<tfoot>
                
<tr>
                 
<td colspan="5"><input class="btn btn-warning pull-right" type="submit" value="Atualizar Carrinho" /></td>
 
 
<tr>
                 
<td colspan="5"><a class="btn btn-default " href="index.php">Continuar Comprando</a></td>
    <tr>
    <td colspan="10"><a class="btn btn-success pull-right" href="#">Finalizar Compra</a></td>
 
        </tfoot>
 
 
<tbody>
                   
    
                     <?php
                         if(count($_SESSION['carrinho']) == 0){
                            echo '<tr><td colspan="5">Não há produto no carrinho</td></tr>';
                         }else{
                            include "config.inc.php";
                            $total1 = 0;
                             $total2=0;
                            foreach($_SESSION['carrinho'] as $id => $quantidade){
                                  $sql1   = "SELECT *  FROM computadores WHERE id= '$id'";
                                  $busca1 = mysqli_query($conexao, $sql1);
                                  $ln1    = mysqli_fetch_assoc($busca1);
                                   
                                  $nome1  = $ln1['nome'];
                                  $preco1 = number_format($ln1['preco'], 2, ',', '.');
                                  $sub1   = number_format($ln1['preco'] * $quantidade, 2, ',', '.');
                                   
                                  $total1 += $ln1['preco'] * $quantidade;
                                
                                
                               echo '<tr >       
                                      <td>'.$nome1.'</td>
                                      <td><input type="text" size="3" name="prod['.$id.']" value="'.$quantidade.'" /></td>
                                      <td>R$ '.$preco1.'</td>
                                      <td>R$ '.$sub1.'</td>
                                      <td><a class="btn btn-danger" href="?acao=del&id='.$id.'">Remover</a></td>
                                      </tr>';
                            }
                               $total1 = number_format($total1, 2, ',', '.');
                                
                               echo '<tr>
                                    <td colspan="4"><b>Total</td>
                                    <td><b>R$ '.$total1.'</b></td>
                                    
                                    </tr>';
                         }
                   ?>
        
         </tbody>
 
            </form>
    
    </table>
    </div>
    <footer>
        <?php
        include "rodape.php";
        ?>
        </footer>
 
    </body>
    </html>

