<?php
include "config.inc.php";

$msg = false;
if(isset($_FILES['arquivo'])){
    $extensao = strtolower(substr($_FILES['arquivo']['name'], -4));
    $novo_nome = md5(time()) . $extensao;
    $diretorio = "upload/";
    move_uploaded_file($_FILES['arquivo']['tmp_name'], $diretorio . $novo_nome);
    
    $sql_code = "INSERT INTO arquivo (id, arquivo, data) VALUES(1, '$novo_nome', NOW())";
     if(!mysqli_query($conexao,$sql_code)){
         $msg = "Falha ao enviar o arquivo";
     }
    else{
        $msg = "Arquivo enviado com sucesso";
     }
}
?>


<?php if($msg != false) echo "<p> $msg </p>"; ?> 
