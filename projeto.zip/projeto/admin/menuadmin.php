<!--
<nav class="navbar-center">
	<div class="container">
		<div class="navbar-header">
			<ul class="nav nav-justified">
				<li><a class="navbar-brand" href="index.php">Home</a></li>
        		<li><a class="navbar-brand" href="?pg=quemsomos">Quem Somos</a></li>
        		<li><a class="navbar-brand" href="?pg=projetos">Projetos</a></li>
        		<li><a class="navbar-brand" href="?pg=faleconosco">Fale Conosco</a></li>
        	</ul>
		</div>
	</div>
</nav>
-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
           <a href="../index.php"> <img  src="../img/logo3.png" class="logo img-responsive" height="90" width="115"></a>
        </div>
        <ul class="nav navbar-nav">
           
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php"><span class="glyphicon glyphicon-user" style="color: #cc1313;"></span> Sair</a></li>
        </ul>
    </div>
</nav>
