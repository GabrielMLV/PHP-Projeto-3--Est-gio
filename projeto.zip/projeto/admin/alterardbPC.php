<?php

$id = $_POST['id'];
$nome = $_POST['nome'];
$preco = $_POST['preco'];
$quantidade = $_POST['quantidade'];
$descricao = $_POST['descricao'];


//$sql2 = mysqli_query($conexao, "SELECT * FROM admin WHERE id='$id'");

$sql = "UPDATE computadores SET nome='$nome', preco='$preco', quantidade='$quantidade', descricao='$descricao' WHERE id=$id";
$altera = mysqli_query($conexao, $sql);

if(!$altera){
    echo "Ocorreu um erro ao atualizar dados no banco de dados. <br>
    <a href='?pg=listar'>Voltar</a>";
}else{
   echo "<h3>Computadores alterado com sucesso!</h3>
<a href='?pg=listar'>Voltar</a>";
}
?>