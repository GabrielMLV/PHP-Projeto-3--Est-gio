<script language='javascript'>

    function confirmaExclusao(aURL) {

        if(confirm('Você tem certeza que deseja excluir?')) {
            location.href = aURL;
        }
    }

</script>
<h2 class="page-header">Produtos</h2>
<?php

    $busca = "Select * from admin order by id";
    $todos = mysqli_query($conexao, $busca);
    
?>

<table class="table table-hoverlabel label-info">
    <thead>
        <th style="width: 25px;">ID</th>
        <th style="width: 205px;">Título</th>
        <th style="width: 205px;">Quantidade</th>
        <th  style="width: 105px;">Alterar</th>
        <th style="width: 105px;">Excluir</th>
    </thead>
    <?php while ($dados=mysqli_fetch_array($todos)) { ?>
    
    <tr class="alert alert-info">
        <td><?=$dados['id'];?></td>
        <td><?=$dados['titulo'];?></td>
        <td><?=$dados['quantidade'];?></td>
        <td><a class="btn btn-warning" href="?pg=alterar&id=<?=$dados['id']; ?>"><small>Alterar</small></a></td>
        <td><a class="btn btn-danger" href="javascript:confirmaExclusao('?pg=excluirdb&id=<?=$dados['id']; ?>')" class="ask">
<small>Excluir</small></a></td>
    </tr>
    
    <?php } ?>

</table>


<hr>
<h2 class="page-header">Computadores</h2>
<?php

    $busca = "Select * from computadores order by id";
    $todos = mysqli_query($conexao, $busca);
    
?>
<table class="table table-hoverlabel label-info">
    <thead>
        <th style="width: 25px;">ID</th>
        <th style="width: 205px;">Título</th>
        <th style="width: 205px;">Preço</th>
        <th  style="width: 105px;">Alterar</th>
        <th style="width: 105px;">Excluir</th>
    </thead>
    <?php while ($dados=mysqli_fetch_array($todos)) { ?>
    
    <tr class="alert alert-info">
        <td><?=$dados['id'];?></td>
        <td><?=$dados['nome'];?></td>
        <td><?=$dados['preco'];?></td>
        <td><a class="btn btn-warning" href="?pg=alterarPC&id=<?=$dados['id']; ?>"><small>Alterar</small></a></td>
        <td><a class="btn btn-danger" href="javascript:confirmaExclusao('?pg=excluirdbPC&id=<?=$dados['id']; ?>')" class="ask">
<small>Excluir</small></a></td>
    </tr>
    
    <?php } ?>

</table>