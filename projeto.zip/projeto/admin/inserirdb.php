<?php
$titulo = $_POST['titulo'];
$subtitulo = $_POST['subtitulo'];
$quantidade = $_POST['quantidade'];
$tipo = $_POST['tipo'];
$texto = $_POST['texto'];
$arquivo = $_POST['arquivo'];

$sql = "INSERT INTO admin (titulo, subtitulo, quantidade, tipo, texto, arquivo) VALUES ('$titulo', '$subtitulo', '$quantidade', '$tipo', '$texto', '$arquivo')";
$insert = mysqli_query($conexao,$sql);

if(!$insert){
	echo "Ocorreu um erro ao cadastrar no banco de dados. Tente Novamente.";
}else{
	echo "<h3>Seção cadastrada com sucesso! </h3>";
}

?>


