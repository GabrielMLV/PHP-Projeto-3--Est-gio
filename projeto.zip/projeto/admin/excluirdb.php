<?php

	$id = $_GET['id'];

	$sql = "DELETE from admin WHERE id = $id";
	$deleta = mysqli_query($conexao, $sql);

	if(!$deleta){
	    echo "Ocorreu um erro ao deletar dados no banco de dados.
	    	<a href='?pg=listar'>Voltar</a>";
	}else{
	   echo "Deletado com sucesso!
			<a href='?pg=listar'>Voltar</a>";
	}

?>

