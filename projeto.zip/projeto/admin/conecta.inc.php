<?php

    $conexao = mysqli_connect("localhost", "root", "");

    if($conexao){
       echo "Conexão estabelicda com sucesso!"; 
    }
    else{
        echo "Conexão Falhou!";
    }

    $db = mysqli_select_db($conexao , "meusite");

    if($db){
        echo "<br>Banco de dados selecionado com sucesso!";
    }
    else{
        echo "<br>Banco de dados não selecionado!";
    }

    $query = mysqli_query($conexao,"SELECT * FROM faleconosco");
       /* "CREATE TABLE faleconosco
        (
        id int PRIMARY KEY AUTO_INCREMENT,
        nome VARCHAR(100),
        email VARCHAR(200),
        telefone INT,
        assunto VARCHAR(50),
        mensagem TEXT
        )
        "*/
        /*"INSERT INTO faleconosco
        (nome,email,telefone,assunto,mensagem) 
        VALUES('Matheus', 
        'lalala@hotmail.com',
        12345678,
        'Enviado',
        'Enviado com sucesso')"
        );
        */
    while($tabela = mysqli_fetch_array($query)){
        echo $tabela['nome']."<br>";
        echo $tabela['email']."<br>";
        echo $tabela['telefone']."<br>";
        echo $tabela['assunto']."<br>";
        echo $tabela['mensagem'];
    }
    

?>