

<?php 
    
    include "config.inc.php";
  
  $entrar = $_POST['entrar'];
  $senha = $_POST['senha'];
  $login = $_POST['login']; 
        
   
    if (isset($_POST["entrar"])) {
        
        session_start();
      $verifica = mysqli_query($conexao, "SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha'");
        
        if (mysqli_num_rows($verifica)<=0){
            unset ($_SESSION['login']);
            unset ($_SESSION['senha']);
            session_destroy();
            echo "<link href='css/bootstrap.css' rel='stylesheet'>";
            echo "<h4 class='pull-right' style='color: red;'>Falha na Autenticação!</h4>";
            
        }else{
            
        $_SESSION['login'] = $login;
        $_SESSION['senha'] = $senha;
         echo "<script type='text/javascript'>location.href = 'admin.php';</script>";
            
        }
    }
    
?>









 <?php
/*
include "config.inc.php";
$entrar = $_POST['entrar'];
$login = isset($_POST["login"]);
$senha = isset($_POST["senha"]);
echo "$login \n $senha";
if (isset($_POST["entrar"])) {
    
    session_start();

    
    echo "$login \n $senha";
    $result = mysqli_query($conexao, "SELECT * FROM usuarios WHERE login = '$login' AND senha = '$senha';");
     echo "$login \n $senha";
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['login'] = $login;
        $_SESSION['senha'] = $senha;
         setcookie("login",$login);
          header("Location:admin/admin.php");
		} else {
        unset ($_SESSION['login']);
        
        unset ($_SESSION['senha']);
        session_destroy();
        echo "<link href='css/bootstrap.css' rel='stylesheet'>";
        echo "<h4 class='pull-right' style='color: red;'>Falha na Autenticação!</h4>";
        
    }

}
*/
?> 
