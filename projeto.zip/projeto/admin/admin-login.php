

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Sistema de Login</title>
    <meta charset="UTF-8">

    <!-- CSS Bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.css">

    <!-- CSS Fonts -->
    <link rel="stylesheet" href="../css/font-awesome.css">

    <!-- CSS Campo de Senha -->
    <link rel="stylesheet" href="../css/locastyle.css">

    <!-- My CSS -->
    <link rel="stylesheet" href="../css/estilo-admin.css">

    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">

</head>

<body>

<div class="container">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4" style="padding-top: 100px;">
            <div class="jumbotron">

                <img src="../img/logo3.png" class="img-responsive center-block"><br>
                <form action="" method="post">

                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user-circle" aria-hidden="true"></i></span>
                        <input type="text" class="form-control" name="nome" placeholder="Usuário">
                    </div>
                    <br>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
                        <input type="text" class="form-control" name="email" placeholder="Senha">
                    </div>
                    <br>

                    <button type="submit" class="btn btn-primary center-block" id="entrar" href="admin/admin.php">Entrar</button>
                    <br>

                    <a href="../index.php" class="text-center" style="margin-left: 75px">Página Inicial</a>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>

</html>