<?php
include "config.inc.php";
$nome = $_POST['nome'];
$preco = $_POST['preco'];
$quantidade = $_POST['quantidade'];
$descricao = $_POST['descricao'];
//$arquivo = $_POST['arquivo'];

$sql = "INSERT INTO computadores (nome, preco, quantidade, descricao) VALUES ('$nome', '$preco', '$quantidade','$descricao')";
$insert = mysqli_query($conexao,$sql);

if(!$insert){
	echo "Ocorreu um erro ao cadastrar no banco de dados. Tente Novamente.";
}else{
	echo "<h3>Seção cadastrada com sucesso! </h3>";
}

?>