<?php

$id = $_GET['id'];
$busca = "SELECT * FROM admin WHERE id=$id";
$sql = mysqli_query($conexao,$busca);

while($dados=mysqli_fetch_array($sql)){

?>


<div class="container">
<form action="?pg=alterardb" method="post" enctype="multipart/form-data">
		<input type="hidden" name="id" id="id" value="<?=$dados['id'];?>" />
		<label>Nome da Seção:</label>
		<input class="form-control" name="titulo" type="text" value="<?=$dados['titulo'];?>"/>

		<label>Preço:</label>
		<input class="form-control" name="subtitulo" type="text" value="<?=$dados['subtitulo'];?>"/>

        <label>Quantidade:</label>
        <input class="form-control" name="quantidade" type="number"value="<?=$dados['quantidade'];?>"/>
    
         <label>Tipo: EX: 1 p/ Processadores, 2 p/ Placa Mãe e 3 p/ Placa de Vídeo</label>
        <input class="form-control" name="tipo" type="number"value="<?=$dados['tipo'];?>"/>

		<label>Texto:</label>
		<textarea class="form-control" rows="8" name="texto" id="texto" value="<?=$dados['texto'];?>"><?=$dados['texto'];?></textarea>
        <label>Imagem:</label>                          
        <br>
		<button class="btn btn-danger" name="Enviar">Alterar</button>
</form>
</div>
<?php } ?>


