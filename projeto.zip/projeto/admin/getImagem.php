<?php
include "config.inc.php";

$PicNum = $_GET["id"];

mysqli_connect($host,$username,$password) or die("Impossível conectar ao banco.");
@mysqli_select_db($db) or die("Impossível conectar ao banco.");
$result=mysqli_query("SELECT * FROM admin WHERE id=$PicNum") or die("Impossível executar a query ");
$row=mysqli_fetch_object($result);
Header( "Content-type: image/gif");
echo $row->arquivo;
?>