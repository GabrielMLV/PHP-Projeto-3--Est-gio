<?php
include "config.inc.php";

$msg = false;
if(isset($_FILES['arquivo'])){
    $extensao = strtolower(substr($_FILES['arquivo']['name'], -4));
    $novo_nome = md5(time()) . $extensao;
    $diretorio = "upload/";
    move_uploaded_file($_FILES['arquivo']['tmp_name'], $diretorio . $novo_nome);
    
    $sql_code = "INSERT INTO arquivo (id, arquivo, data) VALUES(null, '$novo_nome', NOW())";
     if(!mysqli_query($conexao,$sql_code)){
         $msg = "Falha ao enviar o arquivo";
     }else{
        $msg = "Arquivo enviado com sucesso";
    }
}
?>

<div class="container">
	<form action="?pg=inserirdbPC" method="post">
		
        <label>Nome do Computador:</label>
		<input class="form-control" name="nome" type="text"/>

		<label>Preço:</label>
		<input class="form-control" name="preco" type="number"/>

        <label>Quantidade:</label>
        <input class="form-control" name="quantidade" type="number"/>

		<label>Descrição:</label>
		<textarea class="form-control" rows="8" name="descricao" id="texto"></textarea>
        <label>Imagem:</label>
        <input type="file" name="arquivo">
        <br>
        
		<button class="btn btn-success" name="Enviar">Cadastrar</button>
	</form>
</div>