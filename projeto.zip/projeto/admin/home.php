<div class="row">
    <div class="col-lg-12">
        <h3><p>Escolha uma das opções a serem feitas: Listar Cadastrados ou Inserir Novo.</p></h3>
    </div>
</div>
<!-- /.row -->