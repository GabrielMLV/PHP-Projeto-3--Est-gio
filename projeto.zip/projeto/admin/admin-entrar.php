<?php
include "config.inc.php";
/*
session_start();

if (isset($_REQUEST["sair"])) {
    mysqli_close($conexao);
    unset($_SESSION['login']);
    unset($_SESSION['senha']);
    session_destroy();
    header('location:../index.php');
}

if (!isset($_SESSION['login']) and !isset($_SESSION['senha'])) {
    mysqli_close($conexao);
    unset($_SESSION['login']);
    unset($_SESSION['senha']);
    session_destroy();
    header('location:../index.php');
}
*/

?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>X-Computer Login</title>
    <meta charset="UTF-8">

    <!-- CSS Bootstrap -->
    <link rel="stylesheet" href="../css/bootstrap.css">

    <!-- CSS Fonts -->
    <link rel="stylesheet" href="../css/font-awesome.css">

    <!-- CSS Campo de Senha -->
    <link rel="stylesheet" href="../css/locastyle.css">

    <!-- My CSS -->
    <link rel="stylesheet" href="../css/estilo-admin.css">

    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">

</head>

<body>

<div class="container">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4" style="padding-top: 100px;">
            <div class="jumbotron">

                <img src="../img/logo3.png" class="img-responsive center-block"><br>
                <form action="login.php" method="POST" target="">

                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user-circle" aria-hidden="true"></i></span>
                        <input type="text" class="form-control" name="login" placeholder="Usuário">
                    </div>
                    <br>

                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
                        <input type="password" class="form-control" name="senha" placeholder="Senha">
                    </div>
                    <br>
                   <!-- <iframe name="iframe" style="width: 200px; height: 40px; border: none;" scrolling="no"></iframe> -->
                    <button type="submit" class="btn btn-primary center-block" id="entrar" name="entrar" >Entrar</button>
                    <br>

                    <a href="../index.php" class="text-center" style="margin-left: 75px">Página Inicial</a>
                </form>
            </div>
        </div>
    </div>
</div>
    <footer style="padding-top: 20px; padding-bottom: 20px; margin-top: 1px">
       <?php include "../rodape.php"; ?>
    </footer>
    
<script src="js/jquery-3.2.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
</body>

</html>