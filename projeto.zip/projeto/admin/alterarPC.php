<?php

$id = $_GET['id'];
$busca = "SELECT * FROM computadores WHERE id=$id";
$sql = mysqli_query($conexao,$busca);

while($dados=mysqli_fetch_array($sql)){

?>


<div class="container">
<form action="?pg=alterardbPC" method="post" enctype="multipart/form-data">
		<input type="hidden" name="id" id="id" value="<?=$dados['id'];?>" />
		<label>Nome da Seção:</label>
		<input class="form-control" name="nome" type="text" value="<?=$dados['nome'];?>"/>

		<label>Preço:</label>
		<input class="form-control" name="preco" type="number" value="<?=$dados['preco'];?>"/>

        <label>Quantidade:</label>
        <input class="form-control" name="quantidade" type="number"value="<?=$dados['quantidade'];?>"/>

		<label>Texto:</label>
		<textarea class="form-control" rows="8" name="descricao" id="texto" value="<?=$dados['descricao'];?>"><?=$dados['descricao'];?></textarea>
        
          
        <br>
       
		<button class="btn btn-danger" name="Enviar">Alterar</button>
</form>
</div>
<?php } ?>