<?php
          include "config.inc.php";
         
    
    ?>
<!DOCTYPE html>
<html>

<head>

    <title>X-Computer</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="css/estilo.css">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/shop-homepage.css" rel="stylesheet">

    <link rel="stylesheet" href="css/font-awesome.css">

    <link rel="stylesheet" href="css/locastyle.css">

    <link href="https://fonts.googleapis.com/css?family=Abel|Roboto:400,500,700,900" rel="stylesheet">
    
    

</head>

<body>

   <?php
    include "menu.php";
    ?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <div class="col-md-3">
                <p class="lead">Serviços</p>
                <div class="list-group" style="color: #CC1313;">
                    <a href="processadores.php" class="list-group-item">Processadores</a>
                    <a href="placadevideo.php" class="list-group-item">Placa de Vídeo</a>
                    <a href="placamae.php" class="list-group-item">Placa-Mãe</a>
                </div>
                <div>
                <img class="img-responsive" src="img/bannerlado.jpg">
                </div>
            </div>

            <div class="col-md-9">

                <div class="row carousel-holder">

                    <div class="col-md-12">
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img class="slide-image" src="img/banner1.jpg">
                                </div>
                                <div class="item">
                                    <img class="slide-image" src="img/banner2.jpg">
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>
                    </div>

                </div>



                   
                <div class="row center-block">
                     
                    <?php

                    //$id = $_GET['id'];
                        $sql = "SELECT * FROM admin WHERE tipo ='3'";
                        $busca = mysqli_query($conexao, $sql);
                        while($dados = mysqli_fetch_array($busca)){
                            echo '<div class="col-sm-4 col-lg-4 col-md-4">';
                            echo '<div class="thumbnail">';
                            
                            //echo '<img src="upload/'.$dados['arquivo'].'" /> ';
                            echo '<img class="img-responsive" src="img/placavideo.jpg">';
                            echo '<div  class="caption">';
                            //echo '<img src="upload/'.$dados['arquivo'].'" /> ';

                            echo '<h4><a href="#">'.$dados['titulo'].'</a></h4>';
                            echo '<h5 class="" style="" >'.$dados['texto'].'</h5>';

                            echo '<h4 class="pull-right">R$ '.number_format($dados['subtitulo'], 2, ',', '.').'</h4>';
                            echo '<a class="btn btn-danger" style="color: white;" href="carrinho.php?acao=add&id='.$dados['id'].'">Comprar</a>';
                            echo '</div>';                    
                            echo '</div>';
                            echo '</div>';  
                        }
                    
                    ?>
                    

                    

                </div>

            </div>

        </div>

    </div>
    <footer style="padding-top: 20px; padding-bottom: 20px; margin-top: 1px">
       <?php include "rodape.php"; ?>
    </footer>

    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>

</html>