<!DOCTYPE html>
<html>

<head>

    <title>Fale Conosco</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="css/estilo.css">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link href="css/shop-homepage.css" rel="stylesheet">

    <link rel="stylesheet" href="css/font-awesome.css">

    <link rel="stylesheet" href="css/locastyle.css">

    <link href="https://fonts.googleapis.com/css?family=Abel|Roboto:400,500,700,900" rel="stylesheet">

</head>

<body>

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><img src="img/logo3.png" width="130" height="50"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php" style="color: white" class="home">Home</a>
                    </li>

                    <li>
                        <a href="computadores.php" style="color: white" class="computadores">Computadores</a>
                    </li>

                    <li>
                        <a href="faleconosco.php" style="color: white">Fale Conosco</a>
                    </li>

                    <li>
                        <a href="admin/admin-entrar.php" style="color: white"><i class="fa fa-user"></i> Admin</a>
                    </li>

                    <li>
                        <a href="carrinho.php" style="color: white; margin-left: 50px;"><i class="fa fa-shopping-bag"></i> Carrinho</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="col-md-12">
        <div class="row">

            <div class="page-header text-center" style="font-size: 25px"><b>CONTATO</b></div>

                <div class="col-md-6">
                <form class="form-horizontal" action="enviar.php" method="post">
                    <div class="form-group">
                        <label class="control-label col-sm-3">Email:*</label>
                        <div class="col-sm-7">
                            <input type="email" class="form-control" name="email" placeholder="Email">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-3">Assunto:*</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control" name="assunto" placeholder="Assunto">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-3">Mensagem:*</label>
                        <div class="col-sm-7">
                            <textarea class="form-control" rows="5" name="mensagem" placeholder="Mensagem..."></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-10">
                            <button type="submit" class="btn btn-danger">Submit</button>
                        </div>
                    </div>

                </form>
                </div>
                <div class="col-md-6">
                    <img src="img/icon-ajuda.jpg" class="col-sm-offset-3 img-responsive">
                </div>
            </div>

        </div>
    </div>



    <footer style="padding-top: 20px; padding-bottom: 20px; margin-top: 1px">
       <?php include "rodape.php"; ?>
    </footer>

</body>

</html>