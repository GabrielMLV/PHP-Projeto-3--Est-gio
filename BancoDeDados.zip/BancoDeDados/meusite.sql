-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 30-Maio-2017 às 22:09
-- Versão do servidor: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meusite`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `subtitulo` double(5,2) NOT NULL DEFAULT '0.00',
  `texto` text,
  `arquivo` varchar(40) DEFAULT NULL,
  `data` datetime DEFAULT NULL,
  `quantidade` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`id`, `titulo`, `subtitulo`, `texto`, `arquivo`, `data`, `quantidade`) VALUES
(1, 'Processador I7', 650.99, 'PROCESSADOR TOP DE LINHA 9Â° GERAÃ‡ÃƒO ', 'Array', NULL, 15),
(2, 'Notebook Intel', 259.90, 'MUITO BOM', 'Array', NULL, 25),
(5, 'Processador I9', 399.99, 'ZIKAAAAAAAAAAAA', NULL, NULL, 33),
(6, 'Computador Dell', 650.50, 'TA BARATO EIM', NULL, NULL, 14),
(7, 'Processador', 299.99, 'VEM COMPRAR !!!', NULL, NULL, 31),
(8, 'Processador I5', 450.00, 'Muito bom mesmo', NULL, NULL, 16),
(9, 'Placa de VÃ­deo', 750.00, 'Muito Boa', 'Array', NULL, 62),
(10, 'Placa MÃ£e', 379.90, 'Placa foda hahahahaah', 'vagalume.jpg', NULL, 44),
(11, 'teste', 54.00, 'testando', 'logo2.png', NULL, 10),
(12, 'testtt', 45.00, 'aaaa', '004ca8bb7e1d94336517fa05ab4f625e.jpg', NULL, 5),
(13, 'eee', 452.00, 'vcxxcvx', 'fad.jpg', NULL, 1),
(14, 'rrr', 552.00, 'a', 'imagem.jpg', NULL, 4),
(15, 'e', 22.00, '5aa', 'dgdhD1J1lBM.jpg', NULL, 2),
(16, 'q', 32.00, '241a', '1162.jpg', NULL, 1),
(17, 'qqw', 546.00, 'asdas', '360fx360f.png', NULL, 2),
(18, 'q', 4.00, 'asd', '10-bone-aba-reta-young-money-snapback-ca', NULL, 1),
(19, 'aasd', 566.00, 'qweqwe', '21269907829580e616de2fe50.28822544.14773', NULL, 5),
(20, 'er', 156.00, 'b', 'C (6).png', NULL, 23);

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivo`
--

CREATE TABLE `arquivo` (
  `codigo` int(11) NOT NULL,
  `arquivo` varchar(40) NOT NULL,
  `data` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `faleconosco`
--

CREATE TABLE `faleconosco` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `assunto` varchar(50) DEFAULT NULL,
  `mensagem` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `faleconosco`
--

INSERT INTO `faleconosco` (`id`, `nome`, `email`, `telefone`, `assunto`, `mensagem`) VALUES
(1, 'Renan', 'renan97_bs@hotmail.com', 12345678, 'Envio fale conosco', 'Envio via site...');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_carrinho`
--

CREATE TABLE `tbl_carrinho` (
  `id` int(11) NOT NULL,
  `cod` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `preco` double(10,2) NOT NULL,
  `qtd` int(11) NOT NULL,
  `sessao` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_produtos`
--

CREATE TABLE `tbl_produtos` (
  `cod` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `img` varchar(36) NOT NULL,
  `preco` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tbl_produtos`
--

INSERT INTO `tbl_produtos` (`cod`, `nome`, `img`, `preco`) VALUES
(1, 'Notebook HP 2160br', '001.jpg', 5450.00),
(2, 'Computador HP', '002.jpg', 1400.00);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`userid`, `username`, `password`) VALUES
(1, 'administrador', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `codUser` int(11) NOT NULL,
  `login` char(15) NOT NULL,
  `senha` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`codUser`, `login`, `senha`) VALUES
(2, 'admin', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faleconosco`
--
ALTER TABLE `faleconosco`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_carrinho`
--
ALTER TABLE `tbl_carrinho`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_produtos`
--
ALTER TABLE `tbl_produtos`
  ADD PRIMARY KEY (`cod`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`codUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `faleconosco`
--
ALTER TABLE `faleconosco`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_carrinho`
--
ALTER TABLE `tbl_carrinho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_produtos`
--
ALTER TABLE `tbl_produtos`
  MODIFY `cod` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `codUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
